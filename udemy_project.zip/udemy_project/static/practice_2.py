l = [3,5,7,3,5,7,3,545,34,235,234,3]
#Q. Sort it such that seventh element is greatest of all, second element is greater than last element and second last element
# is not greater than sum of 8th and sixth element. (that is 37)
# print(len(l))
x = l[5]
l[5] = l[len(l)-2]
# l[5] = y
l[len(l)-2] = x
count = 0
for i in l:
    print(i,count)
    count+=1

#Hence problem os solved using swapping



# Transfer of url from project to app and then it is transfered to views.py