l = [1,2,3,4,5,6]

for i in range(6):
    print(i)


l1 = ["science","maths","english","hindi","sanskrit","acounts"]
# z = input("Enter the subject name for which you want to check:")
# x = int(input(f"Enter your marks in {z}:"))
for i in range(101):
    attendance = input("Enter your name:")
    if attendance=="break":
        break
    z = input(f"Hi {attendance} Enter the subject name for which you want to check:")
    for i in l1:
        if i not in z:
            print("Wrong input please enter a valid subject")
            # break
            input(f"Hi {attendance} Enter the subject name for which you want to check:")
            continue #require changes


    x = int(input(f"Enter your marks in {z}:"))
    while x>=75:
        print(f"Congratulations {attendance} you got distinction in this subject")
        y = str(input("Do you want the result again answer only in yes or no:"))
        if y=="yes":
            z = input("Enter the subject name for which you want to check:")
            x = int(input(f"Enter your marks in {z}:"))
            continue
        else:
            break

    else:
        print(f"Sorry {attendance} your score is less than 75, you are not eligible for distinction")
        continue

