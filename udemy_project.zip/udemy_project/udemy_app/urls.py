from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path("", views.index,name='landing_page'),
    path("index", views.index, name='index'),
    path("about", views.about, name='about'),
    path("services", views.services, name='services'),
    path('CTC',views.CTC,name='CTC'),
    path('home', views.home, name='home'),
    path('indore',views.indore,name='indore'),
    path('thank_you.html',views.thank_you,name='thank_you')
]