from django.db import models

# Create your models here.
class Thank_you(models.Model):
    name = models.CharField(max_length=120)
    email = models.CharField(max_length=120)
    phone = models.CharField(max_length=12)
    company = models.CharField(max_length=120)
    location = models.CharField(max_length=20)
    date = models.DateField()

    def __str__(self):
        return self.name #this will give us the name who filled the form in django admin backend