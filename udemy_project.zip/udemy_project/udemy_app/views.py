from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime
from .models import Thank_you
# Create your views here.
#url mapping : urls.py of project and urls.py of app and views.py of app
def index(request):
    context = {"var":"Hi my name is Rohit!."}
    return render(request,'base.html',context)
    # return HttpResponse("udemy_django_2")

def about(request):
    # return HttpResponse("django about")
    return render(request, 'about_us.html')

def services(request):
    return HttpResponse("sunil dalle")

def landing_page(request):
    return render(request,'landing_page.html')

def home(request):
    return render(request,'home.html')

def CTC(request):
    return render(request,'CTC.html')

def indore(request):
    return HttpResponse("Contact us on:9303913137")

def thank_you(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        company = request.POST.get('company')
        location = request.POST.get('location')
        thank_you = Thank_you(name=name,email=email,phone=phone,company=company,location=location,date=datetime.today())
        thank_you.save()
    return render(request,'thank_you.html')