from django.contrib import admin
from .models import Thank_you
# Register your models here.
admin.site.register(Thank_you) #registering our model